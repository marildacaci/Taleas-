import React, { createContext, useContext, useEffect, useState } from "react";
import { meApi } from "../api/authApi";

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  async function reload() {
    setLoading(true);
    try {
      const token = localStorage.getItem("accessToken");
      if (!token) {
        setUser(null);
        return null;
      }
      const res = await meApi();
      const u = res?.data || res?.user || null;
      setUser(u);
      return u;
    } catch {
      localStorage.removeItem("accessToken");
      setUser(null);
      return null;
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    localStorage.removeItem("accessToken");
    setUser(null);
  }

  useEffect(() => {
    reload();
  }, []);

  return (
    <AuthCtx.Provider value={{ user, setUser, loading, reload, logout }}>
      {children}
    </AuthCtx.Provider>
  );
}

export function useAuth() {
  return useContext(AuthCtx);
}

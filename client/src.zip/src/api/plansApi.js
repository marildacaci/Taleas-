import { apiFetch } from "./http";
export const listPlansByClubApi = (clubId) => apiFetch(`/api/plans/club/${clubId}`);

import { request } from "./http";

export function loginApi(email, password) {
  return request("/auth/login", { method: "POST", body: { email, password } });
}

export function meApi() {
  return request("/auth/me", { method: "GET" });
}

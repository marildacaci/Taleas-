import { apiFetch } from "./http";

export const createMembershipApi = ({ clubId, planId }) =>
  apiFetch("/api/memberships", { method: "POST", body: { clubId, planId } });

export const myMembershipsApi = () => apiFetch("/api/memberships/my");

export const activeMembershipApi = (clubId) =>
  apiFetch(`/api/memberships/active?clubId=${encodeURIComponent(clubId)}`);

export const cancelMembershipApi = (membershipId) =>
  apiFetch("/api/memberships/cancel", { method: "POST", body: { membershipId } });

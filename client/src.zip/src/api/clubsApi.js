import { apiFetch } from "./http";
export const listClubsApi = () => apiFetch("/api/clubs");

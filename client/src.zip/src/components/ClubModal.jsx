import React, { useEffect, useMemo, useState } from "react";
import "../styles/clubs.css";
import { apiFetch } from "../api/client";

export default function ClubModal({ club, onClose }) {
  const [plans, setPlans] = useState([]);
  const [loadingPlans, setLoadingPlans] = useState(true);
  const [err, setErr] = useState("");
  const [selectedPlanId, setSelectedPlanId] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    (async () => {
      setErr("");
      setSelectedPlanId(null);
      setLoadingPlans(true);
      try {
        const res = await apiFetch(`/plans/club/${club._id}`, { method: "GET" });
        const json = await res.json();
        if (!res.ok || !json.ok) throw new Error(json?.error?.message || json?.error || "Failed to load plans");
        setPlans((json.data || []).filter((p) => p.isActive !== false));
      } catch (e) {
        setErr(e.message);
        setPlans([]);
      } finally {
        setLoadingPlans(false);
      }
    })();
  }, [club._id]);

  const activities = club.catalog || [];

  const selectedPlan = useMemo(
    () => plans.find((p) => p._id === selectedPlanId) || null,
    [plans, selectedPlanId]
  );

  async function onSubscribe() {
    if (!selectedPlan) return;

    setSubmitting(true);
    setErr("");

    try {
      const res = await apiFetch("/memberships", {
        method: "POST",
        body: JSON.stringify({ clubId: club._id, planId: selectedPlan._id })
      });

      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error(json?.error?.message || json?.error || "Subscription failed");

      window.location.href = "/dashboard";
    } catch (e) {
      setErr(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="modal-overlay" onMouseDown={onClose}>
      <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-top">
          <div className="modal-title">CLUB DETAILS</div>
          <button className="modal-close" onClick={onClose}>X</button>
        </div>

        <div className="modal-content">
          <div className="modal-left">
            <div className="modal-cover">
              <img
                src={club.coverImage || "https://via.placeholder.com/900x500?text=Club"}
                alt={club.name}
              />
            </div>

            <h2 className="modal-h1">{club.name}</h2>
            <p className="modal-desc">{club.description || club.address || "No description provided."}</p>

            {err ? <div style={{ marginTop: 10, color: "#cc2b2b" }}>{err}</div> : null}
          </div>

          <div className="modal-right">
            <div className="section-title">Activities</div>
            <div className="pills">
              {activities.length === 0 ? (
                <div style={{ color: "#6b6b6b", fontSize: 13 }}>No activities.</div>
              ) : (
                activities.map((a, idx) => (
                  <div key={`${a.name}-${idx}`} className="pill">
                    {a.name}{a.activityType ? ` • ${a.activityType}` : ""}
                  </div>
                ))
              )}
            </div>

            <div className="section-title">Membership plans</div>
            {loadingPlans ? (
              <div style={{ color: "#6b6b6b", fontSize: 13 }}>Loading plans...</div>
            ) : (
              <div className="plan-list">
                {plans.length === 0 ? (
                  <div style={{ color: "#6b6b6b", fontSize: 13 }}>No plans available.</div>
                ) : (
                  plans.map((p) => (
                    <div
                      key={p._id}
                      className={`plan ${selectedPlanId === p._id ? "selected" : ""}`}
                      onClick={() => setSelectedPlanId(p._id)}
                    >
                      <div>
                        <strong>{p.name}</strong>
                        <div><small>{p.durationDays} days</small></div>
                      </div>
                      <div><strong>{p.price}€</strong></div>
                    </div>
                  ))
                )}
              </div>
            )}

            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={onClose}>Close</button>
              <button
                className="btn btn-primary"
                disabled={!selectedPlan || submitting}
                onClick={onSubscribe}
              >
                {submitting ? "PLEASE WAIT..." : "CONTINUE"}
              </button>
            </div>

            {!selectedPlan ? (
              <div style={{ marginTop: 10, color: "#6b6b6b", fontSize: 12 }}>
                Select a membership plan to continue.
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

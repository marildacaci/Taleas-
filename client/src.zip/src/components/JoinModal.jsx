import { useEffect, useState } from "react";
import { listPlansByClubApi } from "../api/plansApi";
import { createMembershipApi } from "../api/membershipsApi";

export default function JoinModal({ open, club, onClose, onJoined }) {
  const [plans, setPlans] = useState([]);
  const [planId, setPlanId] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !club?._id) return;
    setErr("");
    listPlansByClubApi(club._id)
      .then((j) => {
        const p = j.data || [];
        setPlans(p);
        setPlanId(p[0]?._id || "");
      })
      .catch((e) => setErr(e.message));
  }, [open, club?._id]);

  if (!open) return null;

  async function submit(e) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      await createMembershipApi({ clubId: club._id, planId });
      onJoined?.();
      onClose?.();
    } catch (e2) {
      setErr(e2.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modalBg" onMouseDown={onClose}>
      <div className="modal" onMouseDown={(e)=>e.stopPropagation()}>
        <div className="row">
          <h3>Join: {club?.name}</h3>
          <button className="btn" onClick={onClose}>✕</button>
        </div>

        {err ? <div className="err">{err}</div> : null}

        <form onSubmit={submit} className="col">
          <select value={planId} onChange={(e)=>setPlanId(e.target.value)}>
            {plans.map(p => (
              <option key={p._id} value={p._id}>
                {p.name} — {p.durationDays}d — {p.price} {p.currency}
              </option>
            ))}
          </select>

          <button className="btnPrimary" disabled={loading || !planId}>
            {loading ? "Joining..." : "Join"}
          </button>
        </form>
      </div>
    </div>
  );
}

import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import "../styles/auth.css";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);

  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setErr("");
    setLoading(true);

    try {
      await login(email, password);
      navigate("/dashboard", { replace: true }); // ✅ no reload
    } catch (e) {
      setErr(e.message || "Login failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrapper">
      <div className="auth-card">
        <div className="auth-topbar">
          <div className="auth-badge">CLUB PORTAL</div>
        </div>

        <div className="auth-body">
          <h2 className="auth-title">Sign in</h2>
          <p className="auth-subtitle">Login to access your dashboard.</p>

          <form className="auth-form" onSubmit={onSubmit}>
            <div className="auth-field">
              <div className="auth-label">Email</div>
              <input
                className="auth-input"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="auth-field">
              <div className="auth-label">Password</div>
              <div className="auth-inline">
                <input
                  className="auth-input"
                  type={show ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  style={{ flex: 1 }}
                />
                <button
                  type="button"
                  className="auth-iconbtn"
                  onClick={() => setShow((s) => !s)}
                >
                  {show ? "HIDE" : "SHOW"}
                </button>
              </div>
            </div>

            {err ? <div className="auth-error">{err}</div> : null}

            <button className="auth-button" disabled={loading}>
              {loading ? "LOGGING IN..." : "LOGIN"}
            </button>
          </form>

          <div className="auth-footer">
            Don’t have an account? <Link to="/register">Register</Link>
          </div>

          <div className="auth-footer" style={{ marginTop: 10 }}>
            Back to <Link to="/">Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

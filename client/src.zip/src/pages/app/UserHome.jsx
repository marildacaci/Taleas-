import React from "react";
import { useAuth } from "../../auth/AuthProvider";
import "../../styles/app.css";

export default function UserHome() {
  const { user, logout } = useAuth();

  return (
    <div className="shell">
      <div className="topbar">
        <div>
          <div className="title">User</div>
          <div className="subtitle">Hi, {user?.firstName || user?.email}</div>
        </div>
        <button className="btn ghost" onClick={logout}>Logout</button>
      </div>

      <div className="card glass">
        Këtu në Pjesën 3 do vendosim: Clubs (public) + profile icon + My Memberships tracking.
      </div>
    </div>
  );
}

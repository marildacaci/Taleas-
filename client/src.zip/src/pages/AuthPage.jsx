import { useState } from "react";
import { loginApi, registerApi } from "../api/authApi";
import { setAuth } from "../auth/authStore";

export default function AuthPage({ onDone }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "", password: "", phoneNumber: "", age: ""
  });
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const payload =
        mode === "login"
          ? { email: form.email, password: form.password }
          : {
              firstName: form.firstName,
              lastName: form.lastName,
              email: form.email,
              password: form.password,
              phoneNumber: form.phoneNumber || undefined,
              age: form.age ? Number(form.age) : undefined,
            };

      const json = mode === "login" ? await loginApi(payload) : await registerApi(payload);
      const data = json.data;

      setAuth({ user: data.user, accessToken: data.accessToken, refreshToken: data.refreshToken });
      onDone?.();
    } catch (e2) {
      setErr(e2.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <div className="row">
        <h2>{mode === "login" ? "Login" : "Register"}</h2>
        <div className="row">
          <button className="btn" onClick={() => setMode("login")}>Login</button>
          <button className="btn" onClick={() => setMode("register")}>Register</button>
        </div>
      </div>

      {err ? <div className="err">{err}</div> : null}

      <form onSubmit={submit} className="col">
        {mode === "register" ? (
          <div className="row">
            <input placeholder="First name" value={form.firstName}
              onChange={(e)=>setForm({...form, firstName:e.target.value})}/>
            <input placeholder="Last name" value={form.lastName}
              onChange={(e)=>setForm({...form, lastName:e.target.value})}/>
          </div>
        ) : null}

        <input placeholder="Email" value={form.email}
          onChange={(e)=>setForm({...form, email:e.target.value})}/>
        <input type="password" placeholder="Password" value={form.password}
          onChange={(e)=>setForm({...form, password:e.target.value})}/>

        {mode === "register" ? (
          <div className="row">
            <input placeholder="Phone" value={form.phoneNumber}
              onChange={(e)=>setForm({...form, phoneNumber:e.target.value})}/>
            <input placeholder="Age" value={form.age}
              onChange={(e)=>setForm({...form, age:e.target.value})}/>
          </div>
        ) : null}

        <button className="btnPrimary" disabled={loading}>
          {loading ? "Loading..." : (mode === "login" ? "Login" : "Create account")}
        </button>
      </form>
    </div>
  );
}

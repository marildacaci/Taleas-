import React, { useEffect, useState } from "react";
import "../styles/clubs.css";
import { apiFetch } from "../api/client";
import ClubModal from "../components/ClubModal";

export default function Clubs() {
  const [clubs, setClubs] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    (async () => {
      setLoading(true);
      setErr("");
      try {
        const res = await apiFetch("/clubs/public", { method: "GET" }); // ✅ path pas /api
        const json = await res.json();
        if (!res.ok || !json.ok) throw new Error(json?.error?.message || json?.error || "Failed to load clubs");
        setClubs(json.data || []);
      } catch (e) {
        setErr(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <div className="page-wrap">
      <div className="page-head">
        <div>
          <h1 className="page-title">Clubs</h1>
          <p className="page-sub">Click a club to see activities and membership plans.</p>
        </div>
      </div>

      {loading ? <div className="page-head">Loading...</div> : null}
      {err ? <div className="page-head" style={{ color: "#cc2b2b" }}>{err}</div> : null}

      <div className="grid">
        {clubs.map((c) => (
          <div key={c._id} className="club-card" onClick={() => setSelected(c)}>
            <div className="club-cover">
              <img
                src={c.coverImage || "https://via.placeholder.com/800x400?text=Club"}
                alt={c.name}
              />
            </div>
            <div className="club-body">
              <h3 className="club-name">{c.name}</h3>
              <p className="club-info">{c.description || c.address || "No info."}</p>
            </div>
          </div>
        ))}
      </div>

      {selected ? <ClubModal club={selected} onClose={() => setSelected(null)} /> : null}
    </div>
  );
}

import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import { apiFetch } from "../api/client";
import "../styles/dashboard.css";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [menuOpen, setMenuOpen] = useState(false);

  const [membership, setMembership] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const displayName = useMemo(() => {
    if (!user) return "";
    const full = `${user.firstName || ""} ${user.lastName || ""}`.trim();
    return full || user.email || "User";
  }, [user]);

  const initials = useMemo(() => {
    if (!user) return "U";
    const a = (user.firstName || user.email || "U").trim()[0] || "U";
    const b = (user.lastName || "").trim()[0] || "";
    return (a + b).toUpperCase();
  }, [user]);

  useEffect(() => {
    // Dashboard është protected, por s’e dëmton këtë guard.
    if (!user) return;

    (async () => {
      setLoading(true);
      setErr("");
      try {
        const res = await apiFetch("/memberships/active", { method: "GET" });
        const json = await res.json();

        if (res.status === 404) {
          setMembership(null);
          return;
        }
        if (!res.ok || !json.ok) throw new Error(json?.error?.message || json?.error || "Failed to load membership");

        setMembership(json.data || null);
      } catch (e) {
        setErr(e.message || "Failed to load dashboard");
      } finally {
        setLoading(false);
      }
    })();
  }, [user]);

  async function handleLogout() {
    try {
      await logout?.();
    } finally {
      setMenuOpen(false);
      navigate("/", { replace: true });
    }
  }

  function goLogin() {
    setMenuOpen(false);
    navigate("/login");
  }

  function goHome() {
    setMenuOpen(false);
    navigate("/");
  }

  return (
    <div className="dash-page">
      {/* Top Header */}
      <header className="dash-topbar">
        <div className="dash-brand">
          <div className="dash-mark" />
          <div>
            <div className="dash-title">CLUB PORTAL</div>
            <div className="dash-sub">Dashboard</div>
          </div>
        </div>

        <div className="dash-actions">
          <Link className="dash-link" to="/">Home</Link>

          {/* Avatar / user icon */}
          <button
            className="dash-avatar"
            onClick={() => setMenuOpen(true)}
            aria-label="Open user menu"
            title={user ? displayName : "Menu"}
          >
            {user ? initials : "☰"}
          </button>
        </div>
      </header>

      {/* Main */}
      <main className="dash-main">
        <div className="dash-container">
          <div className="dash-card">
            <div className="dash-card-head">
              <div>
                <div className="dash-h1">Welcome</div>
                <div className="dash-muted">
                  {user ? displayName : "You are not logged in."}
                </div>
              </div>

              {user ? (
                <span className="dash-pill">Logged in</span>
              ) : (
                <span className="dash-pill">Guest</span>
              )}
            </div>

            <div className="dash-divider" />

            {/* Content */}
            {!user ? (
              <div className="dash-empty">
                <div className="dash-empty-title">Guest mode</div>
                <div className="dash-empty-text">
                  You can browse clubs from <b>Home</b>. Login to see your membership and profile.
                </div>
                <div className="dash-row">
                  <button className="dash-btn" onClick={goHome}>Go to Home</button>
                  <button className="dash-btn dark" onClick={goLogin}>Login</button>
                </div>
              </div>
            ) : loading ? (
              <div className="dash-empty">
                <div className="dash-empty-text">Loading your membership...</div>
              </div>
            ) : err ? (
              <div className="dash-error">{err}</div>
            ) : !membership ? (
              <div className="dash-empty">
                <div className="dash-empty-title">No active membership</div>
                <div className="dash-empty-text">
                  Go to <b>Home</b>, choose a club, select a plan and continue to payment.
                </div>
                <div className="dash-row">
                  <button className="dash-btn" onClick={goHome}>Browse Clubs</button>
                </div>
              </div>
            ) : (
              <div className="dash-grid">
                <div className="dash-info">
                  <div className="dash-label">Membership status</div>
                  <div className="dash-value">{membership.status || "active"}</div>
                </div>

                <div className="dash-info">
                  <div className="dash-label">Start</div>
                  <div className="dash-value">
                    {membership.startAt ? new Date(membership.startAt).toLocaleDateString() : "-"}
                  </div>
                </div>

                <div className="dash-info">
                  <div className="dash-label">End</div>
                  <div className="dash-value">
                    {membership.endAt ? new Date(membership.endAt).toLocaleDateString() : "-"}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Off-canvas menu */}
      {menuOpen ? (
        <div className="dash-overlay" onMouseDown={() => setMenuOpen(false)}>
          <aside className="dash-drawer" onMouseDown={(e) => e.stopPropagation()}>
            <div className="dash-drawer-head">
              <div className="dash-drawer-user">
                <div className="dash-avatar big">{user ? initials : "G"}</div>
                <div>
                  <div className="dash-user-name">{user ? displayName : "Guest"}</div>
                  <div className="dash-user-email">{user ? (user.email || "") : "Not logged in"}</div>
                </div>
              </div>

              <button className="dash-x" onClick={() => setMenuOpen(false)}>✕</button>
            </div>

            <div className="dash-drawer-body">
              <div className="dash-section">Navigation</div>
              <button className="dash-item" onClick={goHome}>Home (Clubs)</button>
              <button className="dash-item" onClick={() => { setMenuOpen(false); navigate("/dashboard"); }}>
                Dashboard
              </button>

              {user ? (
                <>
                  <div className="dash-section">Profile</div>
                  <div className="dash-profile">
                    <div className="dash-profile-row">
                      <span className="dash-k">Name</span>
                      <span className="dash-v">{displayName}</span>
                    </div>
                    <div className="dash-profile-row">
                      <span className="dash-k">Email</span>
                      <span className="dash-v">{user.email || "-"}</span>
                    </div>
                    <div className="dash-profile-row">
                      <span className="dash-k">Phone</span>
                      <span className="dash-v">{user.phoneNumber || "-"}</span>
                    </div>
                    <div className="dash-profile-row">
                      <span className="dash-k">Age</span>
                      <span className="dash-v">{user.age ?? "-"}</span>
                    </div>
                  </div>

                  <div className="dash-row" style={{ marginTop: 12 }}>
                    <button className="dash-btn dark" onClick={handleLogout}>Logout</button>
                  </div>
                </>
              ) : (
                <div className="dash-row" style={{ marginTop: 12 }}>
                  <button className="dash-btn dark" onClick={goLogin}>Login</button>
                </div>
              )}
            </div>
          </aside>
        </div>
      ) : null}
    </div>
  );
}

const bcrypt = require("bcryptjs");
const User = require("../models/User");

async function ensureDefaultAdmin() {
  const existingAdmin = await User.findOne({ role: "admin" }).lean();

  if (existingAdmin) {
    console.log("Admin already exists:", existingAdmin.email);
    return;
  }

  const adminEmail = process.env.DEFAULT_ADMIN_EMAIL || "admin@clubapp.com";
  const adminPassword = process.env.DEFAULT_ADMIN_PASSWORD || "Admin123";
  const adminFirstName = process.env.DEFAULT_ADMIN_FIRSTNAME || "Default";
  const adminLastName = process.env.DEFAULT_ADMIN_LASTNAME || "Admin";

  const hashedPassword = await bcrypt.hash(adminPassword, 10);

  await User.create({
    firstName: adminFirstName,
    lastName: adminLastName,
    email: adminEmail,
    passwordHash: hashedPassword,
    role: "admin",
    isActive: true
  });

  console.log("🚀 Default admin created:");
  console.log("   Email:", adminEmail);
  console.log("   Password:", adminPassword);
}

async function runMigrations() {
  console.log("🔄 Running migrations...");

  await ensureDefaultAdmin();

  console.log("✅ Migrations complete.");
}

module.exports = {
  runMigrations
};

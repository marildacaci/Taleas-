const express = require("express");
const router = express.Router();
const u = require("../controllers/userController");
const requireAuth = require("../middlewares/requireAuth");
const requireRole = require("../middlewares/requireRole");

router.post("/", requireAuth, requireRole("admin"), u.create);
router.get("/", requireAuth, requireRole("admin"), u.list);
router.get("/:id", requireAuth, requireRole("admin"), u.getOne);
router.patch("/:id", requireAuth, requireRole("admin"), u.update);
router.delete("/:id", requireAuth, requireRole("admin"), u.remove);

router.patch("/:userId/profile", requireAuth, u.updateMyProfile);

module.exports = router;

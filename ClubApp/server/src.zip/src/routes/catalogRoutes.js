const express = require("express");
const router = express.Router();
const templates = require("../catalog/clubTemplates");

router.get("/club-templates", (req, res) => {
  res.json({
    ok: true,
    data: templates.map((t) => ({ type: t.type, label: t.label }))
  });
});

router.get("/club-templates/:type", (req, res) => {
  const t = templates.find((x) => x.type === req.params.type);
  if (!t) return res.status(404).json({ ok: false, error: "Template not found" });
  res.json({ ok: true, data: t });
});

module.exports = router;

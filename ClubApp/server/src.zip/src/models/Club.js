const mongoose = require("mongoose");

const PlanSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    durationDays: { type: Number, required: true, min: 1 },
    price: { type: Number, required: true, min: 0 }
  },
  { _id: false }
);

const ActivityCatalogSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    activityType: {
      type: String,
      enum: ["class", "training", "match", "event", "other"],
      default: "class"
    }
  },
  { _id: false }
);

const ClubSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true },

    type: { type: String, enum: ["fitness", "dance", "coding"], required: true },

    description: { type: String, default: "" },
    address: { type: String, default: "" },

    coverImage: { type: String, default: "" }, 
    isPublic: { type: Boolean, default: false },

    plans: { type: [PlanSchema], default: [] },
    catalog: { type: [ActivityCatalogSchema], default: [] }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Club", ClubSchema);

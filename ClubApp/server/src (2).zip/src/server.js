require("dotenv").config();

const express = require("express");
const cors = require("cors");

const connectDB = require("./config/db");
const authJwt = require("./middlewares/authJwt");
const errorHandler = require("./middlewares/errorHandler");
const routes = require("./routes");
const { startMembershipJobs } = require("./jobs/membershipJobs");
const { runMigrations } = require("./migrations/runMigrations");

const app = express();

const corsOptions = {
  origin: "http://localhost:5173",
  credentials: true,
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
};

app.use(cors(corsOptions));
app.options(/.*/, cors(corsOptions));

// Safety-net headers (në praktikë i zgjidh këto raste)
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "http://localhost:5173");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.json());

// Auth after CORS
app.use(authJwt);
app.use((req, res, next) => {
  if (req.originalUrl.startsWith("/api/clubs")) {
    console.log("[REQ]", req.method, req.originalUrl, "params:", req.params);
  }
  next();
});

app.get("/", (req, res) => res.json({ ok: true, message: "API running" }));

app.use("/api", routes);

app.use(errorHandler);

async function start() {
  await connectDB();
  await runMigrations();
  startMembershipJobs();

  const PORT = Number(process.env.PORT || 5000);
  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
}

start().catch((e) => {
  console.error("Startup failed:", e);
  process.exit(1);
});

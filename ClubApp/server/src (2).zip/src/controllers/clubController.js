const asyncHandler = require("../utils/asyncHandler");
const Club = require("../models/Club");
const templates = require("../catalog/clubTemplates");

exports.create = asyncHandler(async (req, res) => {
  const { name, type, description, address, coverImage } = req.body;

  if (!name || !type) {
    return res.status(400).json({ ok: false, error: "name and type are required" });
  }

  const template = templates.find(t => t.type === type);
  if (!template) {
    return res.status(400).json({ ok: false, error: "Invalid club type" });
  }

  const club = await Club.create({
    name: name.trim(),
    type,
    description: description || "",
    address: address || "",
    coverImage: coverImage || "",
    isPublic: false,
    plans: template.defaultPlans,
    catalog: template.defaultCatalog
  });

  res.status(201).json({ ok: true, data: club });
});

exports.listPublic = asyncHandler(async (req, res) => {
  const clubs = await Club.find({ isPublic: true }).sort({ createdAt: -1 }).lean();
  res.json({ ok: true, data: clubs });
});

exports.listAllAdmin = asyncHandler(async (req, res) => {
  const clubs = await Club.find({}).sort({ createdAt: -1 }).lean();
  res.json({ ok: true, data: clubs });
});

exports.setVisibility = asyncHandler(async (req, res) => {
  const { isPublic } = req.body;

  if (typeof isPublic !== "boolean") {
    return res.status(400).json({ ok: false, error: "isPublic must be boolean" });
  }

  const club = await Club.findByIdAndUpdate(
    req.params.id,
    { isPublic },
    { new: true }
  );

  if (!club) return res.status(404).json({ ok: false, error: "Club not found" });

  res.json({ ok: true, data: club });
});

exports.update = asyncHandler(async (req, res) => {
  const allowed = ["name", "description", "address", "coverImage"];
  const payload = {};

  for (const k of allowed) {
    if (typeof req.body[k] !== "undefined") payload[k] = req.body[k];
  }

  const club = await Club.findByIdAndUpdate(req.params.id, payload, { new: true });
  if (!club) return res.status(404).json({ ok: false, error: "Club not found" });

  res.json({ ok: true, data: club });
});

exports.remove = asyncHandler(async (req, res) => {
  const club = await Club.findByIdAndDelete(req.params.id);
  if (!club) return res.status(404).json({ ok: false, error: "Club not found" });
  res.json({ ok: true, data: { id: club._id } });
});

exports.listPublic = asyncHandler(async (req, res) => {
  console.log("[HIT] GET /clubs/public", new Date().toISOString());
  const clubs = await Club.find({ isPublic: true }).sort({ createdAt: -1 }).lean();
  res.json({ ok: true, data: clubs });
});

const express = require("express");
const router = express.Router();

const p = require("../controllers/planController");
const requireAuth = require("../middlewares/requireAuth");
const requireRole = require("../middlewares/requireRole");

router.get("/club/:clubId", p.listByClub);
router.get("/:id", p.getOne);

router.post("/", requireAuth, requireRole("admin"), p.create);
router.patch("/:id", requireAuth, requireRole("admin"), p.update);
router.patch("/:id/deactivate", requireAuth, requireRole("admin"), p.deactivate);
router.delete("/:id", requireAuth, requireRole("admin"), p.remove);

module.exports = router;

const express = require("express");
const router = express.Router();
const auth = require("../controllers/authController");
const requireAuth = require("../middlewares/requireAuth"); 


router.post("/register", auth.register);
router.post("/login", auth.login);
router.post("/refresh", auth.refresh);
router.post("/google", auth.googleLogin);

router.get("/me", requireAuth, auth.me);

module.exports = router;

module.exports = [
  {
    type: "fitness",
    label: "Fitness",
    defaultPlans: [
      { name: "Monthly", durationDays: 30, price: 30 },
      { name: "3 Months", durationDays: 90, price: 80 }
    ],
    defaultCatalog: [
      { name: "Yoga", activityType: "class" },
      { name: "Zumba", activityType: "class" },
      { name: "Cardio", activityType: "training" }
    ]
  },
  {
    type: "dance",
    label: "Dance",
    defaultPlans: [
      { name: "Monthly", durationDays: 30, price: 25 },
      { name: "3 Months", durationDays: 90, price: 70 }
    ],
    defaultCatalog: [
      { name: "Hip Hop", activityType: "class" },
      { name: "Ballet", activityType: "class" },
      { name: "Salsa", activityType: "class" }
    ]
  },
  {
    type: "coding",
    label: "Coding",
    defaultPlans: [
      { name: "Monthly", durationDays: 30, price: 40 },
      { name: "3 Months", durationDays: 90, price: 100 }
    ],
    defaultCatalog: [
      { name: "Frontend", activityType: "class" },
      { name: "Backend", activityType: "class" }
    ]
  }
];
